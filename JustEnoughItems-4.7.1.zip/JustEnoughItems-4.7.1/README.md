[![Build Status](https://dvs1.progwml6.com/jenkins/job/JustEnoughItems-MC1.11/badge/icon)](https://dvs1.progwml6.com/jenkins/job/JustEnoughItems-MC1.11) [![](http://cf.way2muchnoise.eu/full_just-enough-items-jei_downloads.svg)](http://minecraft.curseforge.com/projects/just-enough-items-jei) [![](http://cf.way2muchnoise.eu/versions/Minecraft_just-enough-items-jei_all.svg)](http://minecraft.curseforge.com/projects/just-enough-items-jei)

# [JustEnoughItems (JEI)](http://minecraft.curseforge.com/projects/just-enough-items-jei/files)
JustEnoughItems is an Item and Recipe viewing mod with a focus on stability, performance, and ease of use.

This means:
 * just items and recipes
 * clean API for developers
 * not a coremod, no dependencies other than Forge

### [JEI Developer Wiki](https://github.com/mezz/JustEnoughItems/wiki)

IRC: [#JEI on esper.net](http://webchat.esper.net/?nick=JEIGithub...&channels=JEI&prompt=1)
