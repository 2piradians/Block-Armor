package mezz.jei.suffixtree;

import gnu.trove.set.TIntSet;

public interface ISearchTree {
	TIntSet search(String word);
}
