package mezz.jei.api;

/**
 * @deprecated since JEI 4.6.0. This was replaced by default methods in {@link IModPlugin}.
 */
@Deprecated
public abstract class BlankModPlugin implements IModPlugin {

}
