package mezz.jei.api.recipe;

/**
 * @deprecated since JEI 4.6.0. This was replaced by default methods in {@link IRecipeWrapper}.
 */
public abstract class BlankRecipeWrapper implements IRecipeWrapper {

}
