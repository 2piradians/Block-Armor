@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.transfer;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;