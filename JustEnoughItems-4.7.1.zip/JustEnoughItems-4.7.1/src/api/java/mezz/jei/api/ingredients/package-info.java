@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.ingredients;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;